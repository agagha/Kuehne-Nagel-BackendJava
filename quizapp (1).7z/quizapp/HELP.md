# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.7.3/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/2.7.3/maven-plugin/reference/html/#build-image)
* [Spring Web](https://docs.spring.io/spring-boot/docs/2.7.3/reference/htmlsingle/#web)
* [Spring Data JPA](https://docs.spring.io/spring-boot/docs/2.7.3/reference/htmlsingle/#data.sql.jpa-and-spring-data)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)

QUIZ APPLICATION:
Create and save in DB a class model for a Quiz Application

User stories:
- A Quiz is made of N Questions
- Every Question is related to a topic, and has a difficulty rank number
- Every Question has a content and a list of Response
- Every Response has a text and a boolean (correct)
- Questions can have more than 1 Response correct

DATA LAYER:
- Create a Db with relevant tables (provide script .sql)
- Implement a DaoQuestion class that will 
	- save Question into DB.
	- Update Question with a new Question
	- Delete a Question
	- search Question by topic
	
HOW TO RUN:
- Implement test cases with JUnit