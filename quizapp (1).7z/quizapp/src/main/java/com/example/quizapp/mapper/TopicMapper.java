package com.example.quizapp.mapper;

import com.example.quizapp.dto.TopicRequest;
import com.example.quizapp.dto.TopicResponse;
import com.example.quizapp.model.Topic;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(uses = {QuestionMapper.class, QuestionAnswerMapper.class})
public abstract class TopicMapper {

    public static final TopicMapper INSTANCE = Mappers.getMapper(TopicMapper.class);

    public abstract Topic toTopic(TopicRequest topicRequest);

    public abstract TopicResponse toTopicResponse(Topic topic);
}