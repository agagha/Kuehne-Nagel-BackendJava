package com.example.quizapp.controller;

import com.example.quizapp.dto.QuestionCreateDto;
import com.example.quizapp.dto.QuestionDto;
import com.example.quizapp.dto.QuestionEditRequest;
import com.example.quizapp.service.QuestionService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/questions")
@RequiredArgsConstructor
public class QuestionController {

    private final QuestionService questionService;

    @GetMapping("/{questionId}")
    public QuestionDto getQuestion(@PathVariable long questionId){
        return questionService.get(questionId);
    }

    @PostMapping
    public void createQuestion(@RequestBody QuestionCreateDto question){
        questionService.create(question);
    }

    @PutMapping("/{questionId}")
    public void updateQuestion(@RequestBody QuestionEditRequest question, @PathVariable long questionId){
        questionService.edit(question, questionId);
    }

    @DeleteMapping("/{questionId}")
    public void deleteQuestion(@PathVariable long questionId){
        questionService.delete(questionId);
    }
}
