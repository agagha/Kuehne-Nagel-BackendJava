package com.example.quizapp.service.impl;

import com.example.quizapp.dto.QuestionCreateDto;
import com.example.quizapp.dto.QuestionDto;
import com.example.quizapp.dto.QuestionEditRequest;
import com.example.quizapp.mapper.QuestionMapper;
import com.example.quizapp.model.Question;
import com.example.quizapp.model.QuestionResponse;
import com.example.quizapp.repository.QuestionRepository;
import com.example.quizapp.repository.QuestionResponseRepository;
import com.example.quizapp.service.QuestionService;
import com.example.quizapp.service.TopicService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class QuestionServiceImpl implements QuestionService {

    private static final QuestionMapper MAPPER = QuestionMapper.INSTANCE;

    private final QuestionRepository questionRepository;
    private final QuestionResponseRepository questionResponseRepository;
    private final TopicService topicService;

    @Override
    public QuestionDto get(long id) {
        Question question = findQuestion(id);

        return MAPPER.toQuestionDto(question);
    }

    private Question findQuestion(long id) {
        return questionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Question doesn't exist with id: " + id));
    }

    @Override
    public void create(QuestionCreateDto questionCreateDto) {
        topicService.checkTopic(questionCreateDto.getTopicId());
        Question question = MAPPER.toQuestion(questionCreateDto);
        List<QuestionResponse> questionResponseList = question.getQuestionResponses();
        question = questionRepository.save(question);
        for (QuestionResponse questionResponse : questionResponseList){
            questionResponse.setQuestion(question);
        }

        questionResponseRepository.saveAll(questionResponseList);
    }

    @Override
    public void edit(QuestionEditRequest questionEditRequest, long id) {
        topicService.checkTopic(questionEditRequest.getTopicId());
        Question question = findQuestion(id);
        MAPPER.toQuestion(question, questionEditRequest);
        questionRepository.save(question);
    }

    @Override
    public void delete(long id) {
        findQuestion(id);
        questionRepository.deleteById(id);
    }
}
