package com.example.quizapp.controller;

import com.example.quizapp.dto.QuestionDto;
import com.example.quizapp.dto.TopicRequest;
import com.example.quizapp.dto.TopicResponse;
import com.example.quizapp.service.TopicService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/topics")
@RequiredArgsConstructor
public class TopicController {

    private final TopicService topicService;

    @GetMapping("/{topicId}")
    public TopicResponse getTopic(@PathVariable long topicId){
        return topicService.get(topicId);
    }

    @GetMapping("/{topicId}/questions")
    public List<QuestionDto> searchQuestionsByTopicId(@PathVariable long topicId){
        return topicService.search(topicId);
    }

    @PostMapping
    public void createTopic(@RequestBody TopicRequest topicRequest){
        topicService.create(topicRequest);
    }

    @PutMapping("/{topicId}")
    public void updateTopic(@RequestBody TopicRequest topicRequest, @PathVariable long topicId){
        topicService.edit(topicRequest, topicId);
    }

    @DeleteMapping("/{topicId}")
    public void deleteTopic(@PathVariable long topicId){
        topicService.delete(topicId);
    }
}
