package com.example.quizapp.dto;

import lombok.Data;

@Data
public class TopicRequest {
    private String name;
}
