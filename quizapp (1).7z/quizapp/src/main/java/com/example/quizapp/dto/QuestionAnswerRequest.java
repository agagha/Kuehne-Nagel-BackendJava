package com.example.quizapp.dto;

import lombok.Data;

@Data
public class QuestionAnswerRequest {
    private String text;
    private boolean isCorrect;
}
