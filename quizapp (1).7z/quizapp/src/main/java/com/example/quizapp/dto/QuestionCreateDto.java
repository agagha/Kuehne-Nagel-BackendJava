package com.example.quizapp.dto;

import lombok.Data;

import java.util.List;

@Data
public class QuestionCreateDto {
    private String content;
    private int difficulty;
    private Long topicId;
    private List<QuestionAnswerRequest> questionAnswers;
}
