package com.example.quizapp.dto;

import lombok.Data;

@Data
public class QuestionEditRequest {
    private String content;
    private int difficulty;
    private Long topicId;
}
