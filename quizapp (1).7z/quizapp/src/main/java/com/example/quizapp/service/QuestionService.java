package com.example.quizapp.service;

import com.example.quizapp.dto.QuestionCreateDto;
import com.example.quizapp.dto.QuestionDto;
import com.example.quizapp.dto.QuestionEditRequest;

public interface QuestionService {
    QuestionDto get(long id);
    void create(QuestionCreateDto question);
    void edit(QuestionEditRequest questionEditRequest, long id);
    void delete(long id);
}
