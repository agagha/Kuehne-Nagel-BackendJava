package com.example.quizapp.mapper;

import com.example.quizapp.dto.QuestionCreateDto;
import com.example.quizapp.dto.QuestionDto;
import com.example.quizapp.dto.QuestionEditRequest;
import com.example.quizapp.model.Question;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public abstract class QuestionMapper {

    public static final QuestionMapper INSTANCE = Mappers.getMapper(QuestionMapper.class);

    @Mapping(source = "topicId", target = "topic.id")
    @Mapping(source = "questionAnswers", target = "questionResponses")
    public abstract Question toQuestion(QuestionCreateDto questionCreateDto);

    @Mapping(source = "topicId", target = "topic.id")
    public abstract Question toQuestion(@MappingTarget Question question, QuestionEditRequest questionEditRequest);

    @Mapping(target = "topicName", source = "topic.name")
    @Mapping(target = "questionAnswers", source = "questionResponses")
    public abstract QuestionDto toQuestionDto(Question question);

    public abstract List<QuestionDto> toQuestionDtoList(List<Question> questionList);
}