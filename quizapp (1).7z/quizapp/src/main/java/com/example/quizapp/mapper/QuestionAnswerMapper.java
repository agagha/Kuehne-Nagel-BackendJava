package com.example.quizapp.mapper;

import com.example.quizapp.dto.QuestionAnswerRequest;
import com.example.quizapp.dto.QuestionAnswerResponse;
import com.example.quizapp.model.QuestionResponse;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public abstract class QuestionAnswerMapper {

    public static final QuestionAnswerMapper INSTANCE = Mappers.getMapper(QuestionAnswerMapper.class);

    public abstract QuestionResponse toQuestionResponse(QuestionAnswerRequest questionAnswerRequest);

    public abstract List<QuestionResponse> toQuestionResponseList(List<QuestionAnswerRequest> questionAnswerRequestList);

    public abstract QuestionAnswerResponse toQuestionAnswerResponse(QuestionResponse questionResponse);

    public abstract List<QuestionAnswerResponse> toQuestionAnswerResponseList(List<QuestionResponse> questionResponseList);
}