package com.example.quizapp.service;

import com.example.quizapp.dto.QuestionDto;
import com.example.quizapp.dto.TopicRequest;
import com.example.quizapp.dto.TopicResponse;

import java.util.List;

public interface TopicService {

    List<QuestionDto> search(long id);
    TopicResponse get(long id);
    void create(TopicRequest topicRequest);
    void edit(TopicRequest topicRequest, long id);
    void delete(long id);

    void checkTopic(long id);
}
