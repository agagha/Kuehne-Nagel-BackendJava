package com.example.quizapp.service.impl;

import com.example.quizapp.dto.QuestionDto;
import com.example.quizapp.dto.TopicRequest;
import com.example.quizapp.dto.TopicResponse;
import com.example.quizapp.mapper.TopicMapper;
import com.example.quizapp.model.Topic;
import com.example.quizapp.repository.TopicRepository;
import com.example.quizapp.service.TopicService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TopicServiceImpl implements TopicService {

    private final TopicRepository topicRepository;

    private static final TopicMapper MAPPER = TopicMapper.INSTANCE;

    @Override
    public List<QuestionDto> search(long id) {
        Topic topic = topicRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Topic doesn't exist with id: " + id));

        return MAPPER.toTopicResponse(topic).getQuestionList();
    }

    @Override
    public TopicResponse get(long id) {
        Topic topic = topicRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Topic doesn't exist with id: " + id));

        return MAPPER.toTopicResponse(topic);
    }

    @Override
    public void create(TopicRequest topicRequest) {
        Topic topic = MAPPER.toTopic(topicRequest);
        topicRepository.save(topic);
    }

    @Override
    public void edit(TopicRequest topicRequest, long id) {
        Topic topic = topicRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Topic doesn't exist with id: " + id));
        topic.setName(topicRequest.getName());
        topicRepository.save(topic);
    }

    @Override
    public void delete(long id) {
        checkTopic(id);
        topicRepository.deleteById(id);
    }

    @Override
    public void checkTopic(long id) {
        if(!topicRepository.existsById(id)){
            throw new RuntimeException("Topic doesn't exist with id: " + id);
        }
    }
}
