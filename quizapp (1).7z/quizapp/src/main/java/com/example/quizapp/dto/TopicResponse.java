package com.example.quizapp.dto;

import lombok.Data;

import java.util.List;

@Data
public class TopicResponse {
    private Long id;
    private String name;
    private List<QuestionDto> questionList;
}
