package com.example.quizapp.dto;

import lombok.Data;

import java.util.List;

@Data
public class QuestionDto {
    private Long id;
    private String content;
    private int difficulty;
    private String topicName;
    private List<QuestionAnswerResponse> questionAnswers;
}
