package com.example.quizapp.dto;

import lombok.Data;

@Data
public class QuestionAnswerResponse {
    private Long id;
    private String text;
    private boolean isCorrect;
}
