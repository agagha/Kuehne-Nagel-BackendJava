package com.example.quizapp.service.impl;

import com.example.quizapp.dto.QuestionAnswerRequest;
import com.example.quizapp.dto.QuestionCreateDto;
import com.example.quizapp.dto.QuestionDto;
import com.example.quizapp.dto.QuestionEditRequest;
import com.example.quizapp.mapper.QuestionAnswerMapper;
import com.example.quizapp.mapper.QuestionMapper;
import com.example.quizapp.model.Question;
import com.example.quizapp.model.QuestionResponse;
import com.example.quizapp.repository.QuestionRepository;
import com.example.quizapp.repository.QuestionResponseRepository;
import com.example.quizapp.service.TopicService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class QuestionServiceImplTest {

    @InjectMocks
    QuestionServiceImpl questionService;

    @Mock
    QuestionRepository questionRepository;

    @Mock
    QuestionResponseRepository questionResponseRepository;

    @Mock
    TopicService topicService;

    QuestionDto questionDto = new QuestionDto();
    Question question = new Question();
    QuestionResponse questionResponse = new QuestionResponse();
    QuestionAnswerRequest questionAnswerRequest = new QuestionAnswerRequest();

    final Long ID = 25L;

    @BeforeEach
    void setup(){
        String content = "Test question";
        int difficult = 1;

        question.setId(ID);
        question.setContent(content);
        question.setDifficulty(difficult);

        questionAnswerRequest.setCorrect(true);
        questionAnswerRequest.setText("Test answer");

        questionResponse = QuestionAnswerMapper.INSTANCE.toQuestionResponse(questionAnswerRequest);

        question.setQuestionResponses(Collections.singletonList(questionResponse));

        questionDto = QuestionMapper.INSTANCE.toQuestionDto(question);


    }

    @Test
    void getSuccess() {
        when(questionRepository.findById(ID)).thenReturn(Optional.of(question));

        QuestionDto response = questionService.get(ID);

        assertEquals(questionDto.getId(), response.getId());
        assertEquals(questionDto.getContent(), response.getContent());
        assertEquals(questionDto.getDifficulty(), response.getDifficulty());

        verify(questionRepository, times(1)).findById(ID);
    }

    @Test
    void getFailed() {
        when(questionRepository.findById(ID)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> questionService
                .get(ID), "Question doesn't exist with id: " + ID);

        verify(questionRepository, times(1)).findById(ID);
    }

    @Test
    void create() {
        QuestionCreateDto questionCreateDto = new QuestionCreateDto();
        questionCreateDto.setContent("Test question");
        questionCreateDto.setDifficulty(1);
        questionCreateDto.setTopicId(1L);
        questionCreateDto.setQuestionAnswers(Collections.singletonList(questionAnswerRequest));

        when(questionRepository.save(any())).thenReturn(question);

        questionService.create(questionCreateDto);

        verify(topicService, times(1)).checkTopic(anyLong());
        verify(questionRepository, times(1)).save(any());
        verify(questionResponseRepository, times(1)).saveAll(any());
    }

    @Test
    void edit() {
        QuestionEditRequest questionEditRequest = new QuestionEditRequest();
        questionEditRequest.setContent("Test question");
        questionEditRequest.setDifficulty(1);
        questionEditRequest.setTopicId(1L);

        when(questionRepository.findById(ID)).thenReturn(Optional.of(question));

        questionService.edit(questionEditRequest, ID);

        verify(topicService, times(1)).checkTopic(questionEditRequest.getTopicId());
        verify(questionRepository, times(1)).save(question);
    }

    @Test
    void delete() {
        when(questionRepository.findById(ID)).thenReturn(Optional.of(question));

        questionService.delete(ID);

        verify(questionRepository, times(1)).findById(ID);
        verify(questionRepository, times(1)).deleteById(ID);
    }
}