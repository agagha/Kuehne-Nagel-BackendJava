package com.example.quizapp.service.impl;

import com.example.quizapp.dto.QuestionAnswerRequest;
import com.example.quizapp.dto.QuestionDto;
import com.example.quizapp.dto.TopicRequest;
import com.example.quizapp.dto.TopicResponse;
import com.example.quizapp.mapper.QuestionAnswerMapper;
import com.example.quizapp.mapper.QuestionMapper;
import com.example.quizapp.mapper.TopicMapper;
import com.example.quizapp.model.Question;
import com.example.quizapp.model.QuestionResponse;
import com.example.quizapp.model.Topic;
import com.example.quizapp.repository.TopicRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TopicServiceImplTest {

    @InjectMocks
    TopicServiceImpl topicService;

    @Mock
    TopicRepository topicRepository;

    final Long ID = 25L;

    TopicResponse topicResponse = new TopicResponse();
    Topic topic = new Topic();
    Question question = new Question();
    QuestionDto questionDto = new QuestionDto();

    @BeforeEach
    void setup(){
        String content = "Test question";
        int difficult = 1;

        question.setId(ID);
        question.setContent(content);
        question.setDifficulty(difficult);

        questionDto = QuestionMapper.INSTANCE.toQuestionDto(question);

        String topicName = "Test topic";

        topic.setId(ID);
        topic.setName(topicName);
        topic.setQuestionList(Collections.singletonList(question));

        topicResponse = TopicMapper.INSTANCE.toTopicResponse(topic);
    }

    @Test
    void search() {
        List<QuestionDto> questionDtoList = Collections.singletonList(questionDto);

        when(topicRepository.findById(ID)).thenReturn(Optional.of(topic));

        List<QuestionDto> response = topicService.search(ID);

        assertEquals(questionDtoList.size(), response.size());

        verify(topicRepository, times(1)).findById(ID);
    }

    @Test
    void getSuccess() {
        when(topicRepository.findById(ID)).thenReturn(Optional.of(topic));

        TopicResponse response = topicService.get(ID);

        assertEquals(topic.getId(), response.getId());
        assertEquals(topic.getName(), response.getName());
        assertEquals(topic.getQuestionList().size(), response.getQuestionList().size());

        verify(topicRepository, times(1)).findById(ID);
    }

    @Test
    void getFailed() {
        when(topicRepository.findById(ID)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> topicService
                .get(ID), "Topic doesn't exist with id: " + ID);

        verify(topicRepository, times(1)).findById(ID);
    }

    @Test
    void create() {
        TopicRequest topicRequest = new TopicRequest();
        topicRequest.setName("Test topic");

        topicService.create(topicRequest);

        verify(topicRepository, times(1)).save(any());
    }

    @Test
    void edit() {
        TopicRequest topicRequest = new TopicRequest();
        topicRequest.setName("Test topic");

        when(topicRepository.findById(ID)).thenReturn(Optional.of(topic));

        topicService.edit(topicRequest, ID);

        verify(topicRepository, times(1)).save(any());
    }

    @Test
    void delete() {
        when(topicRepository.existsById(ID)).thenReturn(true);

        topicService.delete(ID);

        verify(topicRepository, times(1)).deleteById(anyLong());
        verify(topicRepository, times(1)).existsById(anyLong());
    }

    @Test
    void checkTopicSuccess() {
        when(topicRepository.existsById(ID)).thenReturn(true);

        topicService.checkTopic(ID);

        verify(topicRepository, times(1)).existsById(anyLong());
    }

    @Test
    void checkTopicFailed() {
        when(topicRepository.existsById(ID)).thenReturn(false);

        assertThrows(RuntimeException.class, () -> topicService
                .checkTopic(ID), "Topic doesn't exist with id: " + ID);

        verify(topicRepository, times(1)).existsById(anyLong());
    }
}